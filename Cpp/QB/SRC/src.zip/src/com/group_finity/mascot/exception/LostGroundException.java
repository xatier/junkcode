package com.group_finity.mascot.exception;

public class LostGroundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
