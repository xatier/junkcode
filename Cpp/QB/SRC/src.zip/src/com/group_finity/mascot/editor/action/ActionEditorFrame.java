package com.group_finity.mascot.editor.action;

import javax.swing.JFrame;

public class ActionEditorFrame extends JFrame {

	
}
