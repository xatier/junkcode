package com.group_finity.mascot.win.jna;

import com.sun.jna.Structure;

public class SIZE extends Structure{

	public int cx;
	public int cy;
}
