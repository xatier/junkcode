package com.group_finity.mascot.win.jna;

import com.sun.jna.Structure;

public class POINT extends Structure{

	public int x;
	public int y;
}
