#define PLURK_HOST "www.plurk.com"
#define HTTP_PORT "80"
#define SSL_PORT "443"

#define IS_SSL 1
#define NOT_SSL 0

