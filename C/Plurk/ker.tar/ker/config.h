#if 1
#define PLURK_USERNAME "cciwn2010"
#define PLURK_PASSWORD "wintercamp"
#endif

#if 0
#define PLURK_USERNAME "xatierlike"
#define PLURK_PASSWORD "su3cl3"
#endif

#define PLURK_KEY "2TN9ok19OZiNA2UJ0YQDFmiHy3uCUhiP"
